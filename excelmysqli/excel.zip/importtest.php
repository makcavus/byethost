<?php
	
	###### www.phpkodlari.com #####	
	
	
	include("mysql_excel.inc.php");
	
	$import=new HarImport();
	$import->openDatabase("localhost","user","pwd","database");
	
	// tabloyu direkt EXCEL apan komut
	$import->ImportDataFromTable("tablename");
	
	
	// herhangi bir Mysql komutu cevab�n� EXCEL yapmak	
	$sql="SELECT ad,soyad FROm ogrenciler"
	$import->ImportData($sql,"myXls.xls");

	
		
	//Excel dosyas� �retip download ettirici, true parametresi download ettirir	
	//$import->ImportDataFromTable("graduate","",true);
	//Or
	//$import->ImportData($sql,"myXls.xls",true);

?>